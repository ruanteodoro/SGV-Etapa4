
// Endereço da API PetCare
const API_URL = "https://localhost:7131/api";

// Navegação entre as telas do PetCare

function mostrarSecao(nomeSecao) {

    // Esconde todas as seções
    const secoes = document.querySelectorAll(".secao");

    secoes.forEach(secao => {
        secao.hidden = true;
    });

    // Mostra a seção selecionada
    const secaoSelecionada = document.getElementById(nomeSecao);

    if (secaoSelecionada) {
        secaoSelecionada.hidden = false;
    }

    // Atualiza o título do cabeçalho
    const titulos = {
        inicio: "Painel de Controle",
        tutores: "Cadastro de Tutores",
        animais: "Cadastro de Animais",
        veterinarios: "Cadastro de Veterinários",
        consultas: "Cadastro de Consultas",
        prontuarios: "Prontuários",
        vacinas: "Cadastro de Vacinas",
        servicos: "Cadastro de Serviços",
        pagamentos: "Cadastro de Pagamentos",
        relatorios: "Relatórios e Indicadores"
    };

    document.getElementById("tituloPagina").textContent =
        titulos[nomeSecao] || "PetCare";


// Elementos da tela de tutores
const formTutor = document.getElementById("formTutor");
const listaTutores = document.getElementById("listaTutores");
const mensagemTutor = document.getElementById("mensagemTutor");
let tutorEmEdicao = null;

// Listar tutores cadastrados

window.carregarTutores = async function() {
    try {
        const resposta = await fetch(`${API_URL}/Tutores`);

        if (!resposta.ok) {
            throw new Error("Erro ao buscar tutores.");
        }

        const tutores = await resposta.json();

        listaTutores.innerHTML = "";

        tutores.forEach(tutor => {
            const linha = document.createElement("tr");

            linha.innerHTML = `
                <td>${tutor.nome}</td>
                <td>${tutor.email}</td>
                <td>${tutor.telefone}</td>
                <td>${tutor.endereco}</td>
                <td>
                    <button onclick="editarTutor(${tutor.id})">
                        Editar
                    </button>

                    <button onclick="excluirTutor(${tutor.id})">
                        Excluir
                    </button>
                </td>
            `;

            listaTutores.appendChild(linha);
        });

    } catch (erro) {
        console.error(erro);
        mensagemTutor.textContent =
            "Não foi possível carregar os tutores.";
    }
};


// Cadastrar tutor

formTutor.addEventListener("submit", async function(event) {
    event.preventDefault();

    const tutor = {
        id: tutorEmEdicao ?? 0,
        nome: document.getElementById("nomeTutor").value,
        email: document.getElementById("emailTutor").value,
        telefone: document.getElementById("telefoneTutor").value,
        endereco: document.getElementById("enderecoTutor").value
    };

    const editando = tutorEmEdicao !== null;

    const metodo = editando ? "PUT" : "POST";

    const url = editando
        ? `${API_URL}/Tutores/${tutorEmEdicao}`
        : `${API_URL}/Tutores`;

    try {
        const resposta = await fetch(url, {
            method: metodo,
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(tutor)
        });

        if (!resposta.ok) {
            throw new Error("Erro ao salvar tutor.");
        }

        mensagemTutor.textContent = editando
            ? "Tutor atualizado com sucesso!"
            : "Tutor cadastrado com sucesso!";

        formTutor.reset();
        tutorEmEdicao = null;

        await carregarTutores();

    } catch (erro) {
        console.error(erro);
        mensagemTutor.textContent = "Não foi possível salvar o tutor.";
    }
});


// Carregar tutores ao abrir a página
carregarTutores();

}

// Disponibilizar a função para o botão Editar
window.editarTutor = async function(id) {
    try {
        const resposta = await fetch(`${API_URL}/Tutores/${id}`);

        if (!resposta.ok) {
            throw new Error("Não foi possível buscar o tutor.");
        }

        const tutor = await resposta.json();

        document.getElementById("nomeTutor").value = tutor.nome;
        document.getElementById("emailTutor").value = tutor.email;
        document.getElementById("telefoneTutor").value = tutor.telefone;
        document.getElementById("enderecoTutor").value = tutor.endereco;

        tutorEmEdicao = id;

        mensagemTutor.textContent = "Editando cadastro do tutor.";

    } catch (erro) {
        console.error(erro);
        mensagemTutor.textContent = "Erro ao carregar tutor.";
    }
};


window.excluirTutor = async function(id) {

    const confirmar = confirm(
        "Tem certeza de que deseja excluir este tutor?"
    );

    if (!confirmar) {
        return;
    }

    try {
        const resposta = await fetch(`${API_URL}/Tutores/${id}`, {
            method: "DELETE"
        });

        if (!resposta.ok) {
            throw new Error("Não foi possível excluir o tutor.");
        }

        mensagemTutor.textContent =
            "Tutor excluído com sucesso!";

        await carregarTutores();

    } catch (erro) {
        console.error(erro);

        mensagemTutor.textContent =
            "Erro ao excluir tutor. Verifique se existem animais vinculados.";
    }
};


// CARREGAR TUTORES NO SELECT DE ANIMAIS

async function carregarTutoresNoSelect() {
    const selectTutor = document.getElementById("tutorAnimal");

    try {
        const resposta = await fetch(`${API_URL}/Tutores`);

        if (!resposta.ok) {
            throw new Error("Erro ao buscar tutores.");
        }

        const tutores = await resposta.json();

        selectTutor.innerHTML = '<option value="">Selecione o tutor</option>';

        tutores.forEach(tutor => {
            const opcao = document.createElement("option");

            opcao.value = tutor.id;
            opcao.textContent = tutor.nome;

            selectTutor.appendChild(opcao);
        });

    } catch (erro) {
        console.error(erro);
        selectTutor.innerHTML = '<option value="">Erro ao carregar tutores</option>';
    }
}

carregarTutoresNoSelect();


// CARREGAR ANIMAIS NA TABELA

window.carregarAnimais = async function() {
    const listaAnimais = document.getElementById("listaAnimais");
    const mensagemAnimal = document.getElementById("mensagemAnimal");

    try {
        const resposta = await fetch(`${API_URL}/Animais`);

        if (!resposta.ok) {
            throw new Error("Erro ao buscar animais.");
        }

        const animais = await resposta.json();

        listaAnimais.innerHTML = "";

        animais.forEach(animal => {
            const linha = document.createElement("tr");

            linha.innerHTML = `
                <td>${animal.nome}</td>
                <td>${animal.especie}</td>
                <td>${animal.raca || "-"}</td>
                <td>${animal.sexo}</td>
                <td>${animal.tutor?.nome || "Não informado"}</td>
                <td>
                    <button onclick="editarAnimal(${animal.id})">Editar</button>
                    <button onclick="excluirAnimal(${animal.id})">Excluir</button>
                </td>
            `;

            listaAnimais.appendChild(linha);
        });

    } catch (erro) {
        console.error(erro);
        mensagemAnimal.textContent = "Não foi possível carregar os animais.";
    }
};

carregarAnimais();


// CADASTRAR ANIMAL

const formAnimal = document.getElementById("formAnimal");
let animalEmEdicao = null;


// CADASTRAR E ATUALIZAR ANIMAL

formAnimal.addEventListener("submit", async function(event) {
    event.preventDefault();

    const animal = {
        id: animalEmEdicao ?? 0,
        nome: document.getElementById("nomeAnimal").value,
        especie: document.getElementById("especieAnimal").value,
        raca: document.getElementById("racaAnimal").value,
        dataNascimento: document.getElementById("dataNascimentoAnimal").value,
        sexo: document.getElementById("sexoAnimal").value,
        tutorId: Number(document.getElementById("tutorAnimal").value)
    };

    const editando = animalEmEdicao !== null;

    const metodo = editando ? "PUT" : "POST";

    const url = editando
        ? `${API_URL}/Animais/${animalEmEdicao}`
        : `${API_URL}/Animais`;

    try {
        const resposta = await fetch(url, {
            method: metodo,
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(animal)
        });

        if (!resposta.ok) {
            throw new Error("Erro ao salvar animal.");
        }

        document.getElementById("mensagemAnimal").textContent =
            editando
                ? "Animal atualizado com sucesso!"
                : "Animal cadastrado com sucesso!";

        formAnimal.reset();
        animalEmEdicao = null;

        await carregarAnimais();
        await carregarTutoresNoSelect();

    } catch (erro) {
        console.error(erro);

        document.getElementById("mensagemAnimal").textContent =
            "Não foi possível salvar o animal.";
    }
});



// EDITAR ANIMAL

window.editarAnimal = async function(id) {
    try {
        const resposta = await fetch(`${API_URL}/Animais/${id}`);

        if (!resposta.ok) {
            throw new Error("Não foi possível buscar o animal.");
        }

        const animal = await resposta.json();

        document.getElementById("nomeAnimal").value = animal.nome;
        document.getElementById("especieAnimal").value = animal.especie;
        document.getElementById("racaAnimal").value = animal.raca || "";
        document.getElementById("dataNascimentoAnimal").value =
            animal.dataNascimento.substring(0, 10);
        document.getElementById("sexoAnimal").value = animal.sexo;

        await carregarTutoresNoSelect();

        document.getElementById("tutorAnimal").value = animal.tutorId;

        animalEmEdicao = id;

        document.getElementById("mensagemAnimal").textContent =
            "Editando cadastro do animal.";

    } catch (erro) {
        console.error(erro);

        document.getElementById("mensagemAnimal").textContent =
            "Erro ao carregar animal.";
    }
};


// EXCLUIR ANIMAL

window.excluirAnimal = async function(id) {
    const confirmar = confirm(
        "Tem certeza de que deseja excluir este animal?"
    );

    if (!confirmar) return;

    try {
        const resposta = await fetch(`${API_URL}/Animais/${id}`, {
            method: "DELETE"
        });

        if (!resposta.ok) {
            throw new Error("Não foi possível excluir o animal.");
        }

        document.getElementById("mensagemAnimal").textContent =
            "Animal excluído com sucesso!";

        await carregarAnimais();

    } catch (erro) {
        console.error(erro);

        document.getElementById("mensagemAnimal").textContent =
            "Erro ao excluir animal.";
    }
};


// CARREGAR ANIMAIS NO SELECT DE CONSULTAS

async function carregarAnimaisNoSelect() {
    const selectAnimal = document.getElementById("animalConsulta");

    try {
        const resposta = await fetch(`${API_URL}/Animais`);

        if (!resposta.ok) {
            throw new Error("Erro ao buscar animais.");
        }

        const animais = await resposta.json();

        selectAnimal.innerHTML =
            '<option value="">Selecione o animal</option>';

        animais.forEach(animal => {
            const opcao = document.createElement("option");

            opcao.value = animal.id;
            opcao.textContent = animal.nome;

            selectAnimal.appendChild(opcao);
        });

    } catch (erro) {
        console.error(erro);

        selectAnimal.innerHTML =
            '<option value="">Erro ao carregar animais</option>';
    }
}

carregarAnimaisNoSelect();


// CARREGAR CONSULTAS NA TABELA

window.carregarConsultas = async function() {
    const listaConsultas = document.getElementById("listaConsultas");
    const mensagemConsulta = document.getElementById("mensagemConsulta");

    try {
        const resposta = await fetch(`${API_URL}/Consultas`);

        if (!resposta.ok) {
            throw new Error("Erro ao buscar consultas.");
        }

        const consultas = await resposta.json();

        listaConsultas.innerHTML = "";

        consultas.forEach(consulta => {
            const linha = document.createElement("tr");

            const data = new Date(consulta.dataConsulta)
                .toLocaleString("pt-BR");

            linha.innerHTML = `
                <td>${consulta.animal?.nome || "Não informado"}</td>
                <td>${data}</td>
                <td>${consulta.motivo}</td>
                <td>${consulta.diagnostico || "-"}</td>
                <td>${consulta.tratamento || "-"}</td>
                <td>
                    <button onclick="editarConsulta(${consulta.id})">Editar</button>
                    <button onclick="excluirConsulta(${consulta.id})">Excluir</button>
                </td>
            `;

            listaConsultas.appendChild(linha);
        });

    } catch (erro) {
        console.error(erro);
        mensagemConsulta.textContent =
            "Não foi possível carregar as consultas.";
    }
};

carregarConsultas();


// CADASTRAR CONSULTA

const formConsulta = document.getElementById("formConsulta");
let consultaEmEdicao = null;


// CADASTRAR E ATUALIZAR CONSULTA

formConsulta.addEventListener("submit", async function(event) {
    event.preventDefault();

    const consulta = {
        id: consultaEmEdicao ?? 0,
        animalId: Number(document.getElementById("animalConsulta").value),
        dataConsulta: document.getElementById("dataConsulta").value,
        motivo: document.getElementById("motivoConsulta").value,
        diagnostico: document.getElementById("diagnosticoConsulta").value,
        tratamento: document.getElementById("tratamentoConsulta").value
    };

    const editando = consultaEmEdicao !== null;

    const metodo = editando ? "PUT" : "POST";

    const url = editando
        ? `${API_URL}/Consultas/${consultaEmEdicao}`
        : `${API_URL}/Consultas`;

    try {
        const resposta = await fetch(url, {
            method: metodo,
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(consulta)
        });

        if (!resposta.ok) {
            throw new Error("Erro ao salvar consulta.");
        }

        document.getElementById("mensagemConsulta").textContent =
            editando
                ? "Consulta atualizada com sucesso!"
                : "Consulta cadastrada com sucesso!";

        formConsulta.reset();
        consultaEmEdicao = null;

        await carregarConsultas();
        await carregarAnimaisNoSelect();

    } catch (erro) {
        console.error(erro);

        document.getElementById("mensagemConsulta").textContent =
            "Não foi possível salvar a consulta.";
    }
});



// EDITAR CONSULTA

window.editarConsulta = async function(id) {
    try {
        const resposta = await fetch(`${API_URL}/Consultas/${id}`);

        if (!resposta.ok) {
            throw new Error("Não foi possível buscar a consulta.");
        }

        const consulta = await resposta.json();

        await carregarAnimaisNoSelect();

        document.getElementById("animalConsulta").value =
            consulta.animalId;

        const data = new Date(consulta.dataConsulta);
        data.setMinutes(data.getMinutes() - data.getTimezoneOffset());

        document.getElementById("dataConsulta").value =
            data.toISOString().slice(0, 16);

        document.getElementById("motivoConsulta").value =
            consulta.motivo;

        document.getElementById("diagnosticoConsulta").value =
            consulta.diagnostico || "";

        document.getElementById("tratamentoConsulta").value =
            consulta.tratamento || "";

        consultaEmEdicao = id;

        document.getElementById("mensagemConsulta").textContent =
            "Editando cadastro da consulta.";

    } catch (erro) {
        console.error(erro);

        document.getElementById("mensagemConsulta").textContent =
            "Erro ao carregar consulta.";
    }
};


// EXCLUIR CONSULTA

window.excluirConsulta = async function(id) {
    const confirmar = confirm(
        "Tem certeza de que deseja excluir esta consulta?"
    );

    if (!confirmar) return;

    try {
        const resposta = await fetch(`${API_URL}/Consultas/${id}`, {
            method: "DELETE"
        });

        if (!resposta.ok) {
            throw new Error("Não foi possível excluir a consulta.");
        }

        document.getElementById("mensagemConsulta").textContent =
            "Consulta excluída com sucesso!";

        await carregarConsultas();

    } catch (erro) {
        console.error(erro);

        document.getElementById("mensagemConsulta").textContent =
            "Erro ao excluir consulta.";
    }
};


// CARREGAR VETERINÁRIOS NA TABELA

window.carregarVeterinarios = async function() {
    const listaVeterinarios = document.getElementById("listaVeterinarios");
    const mensagemVeterinario = document.getElementById("mensagemVeterinario");

    try {
        const resposta = await fetch(`${API_URL}/Veterinarios`);

        if (!resposta.ok) {
            throw new Error("Erro ao buscar veterinários.");
        }

        const veterinarios = await resposta.json();

        listaVeterinarios.innerHTML = "";

        veterinarios.forEach(veterinario => {
            const linha = document.createElement("tr");

            linha.innerHTML = `
                <td>${veterinario.nome}</td>
                <td>${veterinario.crmv}</td>
                <td>${veterinario.email}</td>
                <td>${veterinario.telefone}</td>
                <td>${veterinario.especialidade}</td>
                <td>
                    <button onclick="editarVeterinario(${veterinario.id})">Editar</button>
                    <button onclick="excluirVeterinario(${veterinario.id})">Excluir</button>
                </td>
            `;

            listaVeterinarios.appendChild(linha);
        });

    } catch (erro) {
        console.error(erro);

        mensagemVeterinario.textContent =
            "Não foi possível carregar os veterinários.";
    }
};

carregarVeterinarios();


// CADASTRAR VETERINÁRIO

const formVeterinario = document.getElementById("formVeterinario");
let veterinarioEmEdicao = null;


formVeterinario.addEventListener("submit", async function(event) {
    event.preventDefault();

    const veterinario = {
        id: veterinarioEmEdicao ?? 0,
        nome: document.getElementById("nomeVeterinario").value,
        crmv: document.getElementById("crmvVeterinario").value,
        email: document.getElementById("emailVeterinario").value,
        telefone: document.getElementById("telefoneVeterinario").value,
        especialidade: document.getElementById("especialidadeVeterinario").value
    };

    const editando = veterinarioEmEdicao !== null;

    try {
        const resposta = await fetch(
            editando
                ? `${API_URL}/Veterinarios/${veterinarioEmEdicao}`
                : `${API_URL}/Veterinarios`,
            {
                method: editando ? "PUT" : "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify(veterinario)
            }
        );

        if (!resposta.ok) {
            throw new Error("Erro ao salvar veterinário.");
        }

        document.getElementById("mensagemVeterinario").textContent =
            editando
                ? "Veterinário atualizado com sucesso!"
                : "Veterinário cadastrado com sucesso!";

        formVeterinario.reset();
        veterinarioEmEdicao = null;

        await carregarVeterinarios();

    } catch (erro) {
        console.error(erro);
        document.getElementById("mensagemVeterinario").textContent =
            "Não foi possível salvar o veterinário.";
    }
});


window.editarVeterinario = async function(id) {
    try {
        const resposta = await fetch(`${API_URL}/Veterinarios/${id}`);

        if (!resposta.ok) {
            throw new Error("Erro ao buscar veterinário.");
        }

        const veterinario = await resposta.json();

        document.getElementById("nomeVeterinario").value = veterinario.nome;
        document.getElementById("crmvVeterinario").value = veterinario.crmv;
        document.getElementById("emailVeterinario").value = veterinario.email;
        document.getElementById("telefoneVeterinario").value = veterinario.telefone;
        document.getElementById("especialidadeVeterinario").value = veterinario.especialidade;

        veterinarioEmEdicao = veterinario.id;

        document.getElementById("mensagemVeterinario").textContent =
            "Altere os dados e clique em Cadastrar Veterinário para salvar.";

    } catch (erro) {
        console.error(erro);
        document.getElementById("mensagemVeterinario").textContent =
            "Não foi possível carregar os dados do veterinário.";
    }
};

window.excluirVeterinario = async function(id) {

    const confirmar = confirm("Deseja realmente excluir este veterinário?");

    if (!confirmar) {
        return;
    }

    try {
        const resposta = await fetch(`${API_URL}/Veterinarios/${id}`, {
            method: "DELETE"
        });

        if (!resposta.ok) {
            throw new Error("Erro ao excluir veterinário.");
        }

        document.getElementById("mensagemVeterinario").textContent =
            "Veterinário excluído com sucesso!";

        await carregarVeterinarios();

    } catch (erro) {
        console.error(erro);

        document.getElementById("mensagemVeterinario").textContent =
            "Não foi possível excluir o veterinário.";
    }
};


 // CARREGAR ANIMAIS NO SELECT DE PRONTUÁRIOS

 async function carregarAnimaisNoSelectProntuario() {
    const select = document.getElementById("animalProntuario");

    try {
        const resposta = await fetch(`${API_URL}/Animais`);

        if (!resposta.ok) {
            throw new Error("Erro ao carregar animais.");
        }

        const animais = await resposta.json();

        select.innerHTML = '<option value="">Selecione o animal</option>';

        animais.forEach(animal => {
            const opcao = document.createElement("option");

            opcao.value = animal.id;
            opcao.textContent = animal.nome;

            select.appendChild(opcao);
        });

    } catch (erro) {
        console.error(erro);
    }
}

carregarAnimaisNoSelectProntuario();


 // CARREGAR PRONTUÁRIOS NA TABELA

 window.carregarProntuarios = async function() {
    const lista = document.getElementById("listaProntuarios");
    const mensagem = document.getElementById("mensagemProntuario");

    try {
        const resposta = await fetch(`${API_URL}/Prontuarios`);

        if (!resposta.ok) {
            throw new Error("Erro ao buscar prontuários.");
        }

        const prontuarios = await resposta.json();

        lista.innerHTML = "";

        prontuarios.forEach(prontuario => {
            const linha = document.createElement("tr");

            const data = new Date(prontuario.dataRegistro)
                .toLocaleString("pt-BR");

            linha.innerHTML = `
                <td>${prontuario.animal?.nome || "Não informado"}</td>
                <td>${data}</td>
                <td>${prontuario.descricao}</td>
                <td>${prontuario.diagnostico || "-"}</td>
                <td>${prontuario.tratamento || "-"}</td>
                <td>${prontuario.observacoes || "-"}</td>
                <td>
                    <button onclick="editarProntuario(${prontuario.id})">
                        Editar
                    </button>
                    <button onclick="excluirProntuario(${prontuario.id})">
                        Excluir
                    </button>
                </td>
            `;

            lista.appendChild(linha);
        });

    } catch (erro) {
        console.error(erro);
        mensagem.textContent =
            "Não foi possível carregar os prontuários.";
    }
};

carregarProntuarios();


 // CADASTRAR PRONTUÁRIO

 const formProntuario = document.getElementById("formProntuario");
 let prontuarioEmEdicao = null;

 
formProntuario.addEventListener("submit", async function(event) {
    event.preventDefault();

    const prontuario = {
        id: prontuarioEmEdicao ?? 0,
        animalId: Number(document.getElementById("animalProntuario").value),
        dataRegistro: document.getElementById("dataRegistro").value,
        descricao: document.getElementById("descricaoProntuario").value,
        diagnostico: document.getElementById("diagnosticoProntuario").value,
        tratamento: document.getElementById("tratamentoProntuario").value,
        observacoes: document.getElementById("observacoesProntuario").value
    };

    const editando = prontuarioEmEdicao !== null;

    try {
        const resposta = await fetch(
            editando
                ? `${API_URL}/Prontuarios/${prontuarioEmEdicao}`
                : `${API_URL}/Prontuarios`,
            {
                method: editando ? "PUT" : "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify(prontuario)
            }
        );

        if (!resposta.ok) {
            throw new Error("Erro ao salvar prontuário.");
        }

        document.getElementById("mensagemProntuario").textContent =
            editando
                ? "Prontuário atualizado com sucesso!"
                : "Prontuário cadastrado com sucesso!";

        formProntuario.reset();
        prontuarioEmEdicao = null;

        await carregarProntuarios();

    } catch (erro) {
        console.error(erro);

        document.getElementById("mensagemProntuario").textContent =
            "Não foi possível salvar o prontuário.";
    }
});


window.editarProntuario = async function(id) {
    try {
        const resposta = await fetch(`${API_URL}/Prontuarios/${id}`);

        if (!resposta.ok) {
            throw new Error("Erro ao buscar prontuário.");
        }

        const prontuario = await resposta.json();

        await carregarAnimaisNoSelectProntuario();

        document.getElementById("animalProntuario").value =
            prontuario.animalId;

        const data = new Date(prontuario.dataRegistro);
        data.setMinutes(data.getMinutes() - data.getTimezoneOffset());

        document.getElementById("dataRegistro").value =
            data.toISOString().slice(0, 16);

        document.getElementById("descricaoProntuario").value =
            prontuario.descricao;

        document.getElementById("diagnosticoProntuario").value =
            prontuario.diagnostico;

        document.getElementById("tratamentoProntuario").value =
            prontuario.tratamento;

        document.getElementById("observacoesProntuario").value =
            prontuario.observacoes;

        prontuarioEmEdicao = prontuario.id;

        document.getElementById("mensagemProntuario").textContent =
            "Altere os dados e clique em Cadastrar Prontuário para salvar.";

    } catch (erro) {
        console.error(erro);

        document.getElementById("mensagemProntuario").textContent =
            "Não foi possível carregar o prontuário.";
    }
};


window.excluirProntuario = async function(id) {

    const confirmar = confirm(
        "Deseja realmente excluir este prontuário?"
    );

    if (!confirmar) {
        return;
    }

    try {
        const resposta = await fetch(`${API_URL}/Prontuarios/${id}`, {
            method: "DELETE"
        });

        if (!resposta.ok) {
            throw new Error("Erro ao excluir prontuário.");
        }

        document.getElementById("mensagemProntuario").textContent =
            "Prontuário excluído com sucesso!";

        await carregarProntuarios();

    } catch (erro) {
        console.error(erro);

        document.getElementById("mensagemProntuario").textContent =
            "Não foi possível excluir o prontuário.";
    }
};


 // CARREGAR ANIMAIS NO SELECT DE VACINAS

 async function carregarAnimaisNoSelectVacina() {
    const select = document.getElementById("animalVacina");

    try {
        const resposta = await fetch(`${API_URL}/Animais`);

        if (!resposta.ok) {
            throw new Error("Erro ao carregar animais.");
        }

        const animais = await resposta.json();

        select.innerHTML = '<option value="">Selecione o animal</option>';

        animais.forEach(animal => {
            const opcao = document.createElement("option");

            opcao.value = animal.id;
            opcao.textContent = animal.nome;

            select.appendChild(opcao);
        });

    } catch (erro) {
        console.error(erro);
    }
}

carregarAnimaisNoSelectVacina();


 // CARREGAR VACINAS NA TABELA

 window.carregarVacinas = async function() {
    const lista = document.getElementById("listaVacinas");
    const mensagem = document.getElementById("mensagemVacina");

    try {
        const resposta = await fetch(`${API_URL}/Vacinas`);

        if (!resposta.ok) {
            throw new Error("Erro ao buscar vacinas.");
        }

        const vacinas = await resposta.json();

        lista.innerHTML = "";

        vacinas.forEach(vacina => {
            const linha = document.createElement("tr");

            const dataAplicacao = new Date(vacina.dataAplicacao)
                .toLocaleDateString("pt-BR");

            const dataProximaDose = vacina.dataProximaDose
                ? new Date(vacina.dataProximaDose).toLocaleDateString("pt-BR")
                : "-";

            linha.innerHTML = `
                <td>${vacina.animal?.nome || "Não informado"}</td>
                <td>${vacina.nome}</td>
                <td>${dataAplicacao}</td>
                <td>${dataProximaDose}</td>
                <td>${vacina.veterinarioResponsavel}</td>
                <td>${vacina.observacoes || "-"}</td>
                <td>
                    <button onclick="editarVacina(${vacina.id})">
                        Editar
                    </button>
                    <button onclick="excluirVacina(${vacina.id})">
                        Excluir
                    </button>
                </td>
            `;

            lista.appendChild(linha);
        });

    } catch (erro) {
        console.error(erro);

        mensagem.textContent =
            "Não foi possível carregar as vacinas.";
    }
};

carregarVacinas();


 // CADASTRAR VACINA

 const formVacina = document.getElementById("formVacina");
 let vacinaEmEdicao = null;

 
formVacina.addEventListener("submit", async function(event) {
    event.preventDefault();

    const vacina = {
        id: vacinaEmEdicao ?? 0,
        animalId: Number(document.getElementById("animalVacina").value),
        nome: document.getElementById("nomeVacina").value,
        dataAplicacao: document.getElementById("dataAplicacao").value,
        dataProximaDose:
            document.getElementById("dataProximaDose").value || null,
        veterinarioResponsavel:
            document.getElementById("veterinarioResponsavel").value,
        observacoes: document.getElementById("observacoesVacina").value
    };

    const editando = vacinaEmEdicao !== null;

    try {
        const resposta = await fetch(
            editando
                ? `${API_URL}/Vacinas/${vacinaEmEdicao}`
                : `${API_URL}/Vacinas`,
            {
                method: editando ? "PUT" : "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify(vacina)
            }
        );

        if (!resposta.ok) {
            throw new Error("Erro ao salvar vacina.");
        }

        document.getElementById("mensagemVacina").textContent =
            editando
                ? "Vacina atualizada com sucesso!"
                : "Vacina cadastrada com sucesso!";

        formVacina.reset();
        vacinaEmEdicao = null;

        await carregarVacinas();

    } catch (erro) {
        console.error(erro);

        document.getElementById("mensagemVacina").textContent =
            "Não foi possível salvar a vacina.";
    }
});


window.editarVacina = async function(id) {
    try {
        const resposta = await fetch(`${API_URL}/Vacinas/${id}`);

        if (!resposta.ok) {
            throw new Error("Erro ao buscar vacina.");
        }

        const vacina = await resposta.json();

        await carregarAnimaisNoSelectVacina();

        document.getElementById("animalVacina").value =
            vacina.animalId;

        document.getElementById("nomeVacina").value =
            vacina.nome;

        document.getElementById("dataAplicacao").value =
            vacina.dataAplicacao.slice(0, 10);

        document.getElementById("dataProximaDose").value =
            vacina.dataProximaDose
                ? vacina.dataProximaDose.slice(0, 10)
                : "";

        document.getElementById("veterinarioResponsavel").value =
            vacina.veterinarioResponsavel;

        document.getElementById("observacoesVacina").value =
            vacina.observacoes;

        vacinaEmEdicao = vacina.id;

        document.getElementById("mensagemVacina").textContent =
            "Altere os dados e clique em Cadastrar Vacina para salvar.";

    } catch (erro) {
        console.error(erro);

        document.getElementById("mensagemVacina").textContent =
            "Não foi possível carregar os dados da vacina.";
    }
};


window.excluirVacina = async function(id) {
    if (!confirm("Deseja realmente excluir esta vacina?")) {
        return;
    }

    try {
        const resposta = await fetch(`${API_URL}/Vacinas/${id}`, {
            method: "DELETE"
        });

        if (!resposta.ok) {
            throw new Error("Erro ao excluir vacina.");
        }

        document.getElementById("mensagemVacina").textContent =
            "Vacina excluída com sucesso!";

        await carregarVacinas();

    } catch (erro) {
        console.error(erro);

        document.getElementById("mensagemVacina").textContent =
            "Não foi possível excluir a vacina.";
    }
};


window.carregarServicos = async function() {
    try {
        const resposta = await fetch(`${API_URL}/Servicos`);

        if (!resposta.ok) {
            throw new Error("Erro ao carregar serviços.");
        }

        const servicos = await resposta.json();

        const lista = document.getElementById("listaServicos");

        lista.innerHTML = "";

        servicos.forEach(servico => {
            lista.innerHTML += `
                <tr>
                    <td>${servico.nome}</td>
                    <td>${servico.descricao}</td>
                    <td>R$ ${Number(servico.preco).toFixed(2).replace(".", ",")}</td>
                    <td>${servico.duracaoMinutos} minutos</td>
                    <td>
                        <button onclick="editarServico(${servico.id})">
                            Editar
                        </button>

                        <button onclick="excluirServico(${servico.id})">
                            Excluir
                        </button>
                    </td>
                </tr>
            `;
        });

    } catch (erro) {
        console.error(erro);

        document.getElementById("mensagemServico").textContent =
            "Não foi possível carregar os serviços.";
    }
};

carregarServicos();


const formServico = document.getElementById("formServico");

let servicoEmEdicao = null;

formServico.addEventListener("submit", async function(event) {
    event.preventDefault();

    const servico = {
        id: servicoEmEdicao ?? 0,
        nome: document.getElementById("nomeServico").value,
        descricao: document.getElementById("descricaoServico").value,
        preco: Number(document.getElementById("precoServico").value),
        duracaoMinutos: Number(document.getElementById("duracaoServico").value)
    };

    const editando = servicoEmEdicao !== null;

    try {
        const resposta = await fetch(
            editando
                ? `${API_URL}/Servicos/${servicoEmEdicao}`
                : `${API_URL}/Servicos`,
            {
                method: editando ? "PUT" : "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify(servico)
            }
        );

        if (!resposta.ok) {
            throw new Error("Erro ao salvar serviço.");
        }

        document.getElementById("mensagemServico").textContent =
            editando
                ? "Serviço atualizado com sucesso!"
                : "Serviço cadastrado com sucesso!";

        formServico.reset();
        servicoEmEdicao = null;

        await carregarServicos();

    } catch (erro) {
        console.error(erro);

        document.getElementById("mensagemServico").textContent =
            "Não foi possível salvar o serviço.";
    }
});


window.editarServico = async function(id) {
    try {
        const resposta = await fetch(`${API_URL}/Servicos/${id}`);

        if (!resposta.ok) {
            throw new Error("Erro ao buscar serviço.");
        }

        const servico = await resposta.json();

        document.getElementById("nomeServico").value =
            servico.nome;

        document.getElementById("descricaoServico").value =
            servico.descricao;

        document.getElementById("precoServico").value =
            servico.preco;

        document.getElementById("duracaoServico").value =
            servico.duracaoMinutos;

        servicoEmEdicao = servico.id;

        document.getElementById("mensagemServico").textContent =
            "Altere os dados e clique em Cadastrar Serviço para salvar.";

    } catch (erro) {
        console.error(erro);

        document.getElementById("mensagemServico").textContent =
            "Não foi possível carregar os dados do serviço.";
    }
};


window.excluirServico = async function(id) {
    if (!confirm("Deseja realmente excluir este serviço?")) {
        return;
    }

    try {
        const resposta = await fetch(`${API_URL}/Servicos/${id}`, {
            method: "DELETE"
        });

        if (!resposta.ok) {
            throw new Error("Erro ao excluir serviço.");
        }

        document.getElementById("mensagemServico").textContent =
            "Serviço excluído com sucesso!";

        await carregarServicos();

    } catch (erro) {
        console.error(erro);

        document.getElementById("mensagemServico").textContent =
            "Não foi possível excluir o serviço.";
    }
};


async function carregarTutoresNoSelectPagamento() {
    try {
        const resposta = await fetch(`${API_URL}/Tutores`);

        if (!resposta.ok) {
            throw new Error("Erro ao carregar tutores.");
        }

        const tutores = await resposta.json();

        const select = document.getElementById("tutorPagamento");

        select.innerHTML = '<option value="">Selecione o tutor</option>';

        tutores.forEach(tutor => {
            const option = document.createElement("option");
            option.value = tutor.id;
            option.textContent = tutor.nome;
            select.appendChild(option);
        });

    } catch (erro) {
        console.error("Erro ao carregar tutores:", erro);
    }
}

carregarTutoresNoSelectPagamento();


window.carregarPagamentos = async function() {
    try {
        const resposta = await fetch(`${API_URL}/Pagamentos`);

        if (!resposta.ok) {
            throw new Error("Erro ao carregar pagamentos.");
        }

        const pagamentos = await resposta.json();

        const lista = document.getElementById("listaPagamentos");
        lista.innerHTML = "";

        pagamentos.forEach(pagamento => {
            const linha = document.createElement("tr");

            linha.innerHTML = `
                <td>${pagamento.tutor?.nome || "Não informado"}</td>
                <td>${Number(pagamento.valor).toLocaleString("pt-BR", {
                    style: "currency",
                    currency: "BRL"
                })}</td>
                <td>${new Date(pagamento.dataPagamento).toLocaleString("pt-BR")}</td>
                <td>${pagamento.formaPagamento}</td>
                <td>${pagamento.status}</td>
                <td>${pagamento.descricao}</td>
                <td>
                    <button onclick="editarPagamento(${pagamento.id})">Editar</button>
                    <button onclick="excluirPagamento(${pagamento.id})">Excluir</button>
                </td>
            `;

            lista.appendChild(linha);
        });

    } catch (erro) {
        console.error("Erro ao carregar pagamentos:", erro);
    }
};

carregarPagamentos();


let pagamentoEmEdicao = null;

formPagamento.addEventListener("submit", async function(event) {
    event.preventDefault();

    const pagamento = {
        id: pagamentoEmEdicao ?? 0,
        tutorId: Number(document.getElementById("tutorPagamento").value),
        valor: Number(document.getElementById("valorPagamento").value),
        dataPagamento: document.getElementById("dataPagamento").value,
        formaPagamento: document.getElementById("formaPagamento").value,
        status: document.getElementById("statusPagamento").value,
        descricao: document.getElementById("descricaoPagamento").value
    };

    try {
        const editando = pagamentoEmEdicao !== null;

        const resposta = await fetch(
            editando
                ? `${API_URL}/Pagamentos/${pagamentoEmEdicao}`
                : `${API_URL}/Pagamentos`,
            {
                method: editando ? "PUT" : "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify(pagamento)
            }
        );

        if (!resposta.ok) {
            const erro = await resposta.text();
            throw new Error(erro || "Erro ao salvar pagamento.");
        }

        alert(editando
            ? "Pagamento atualizado com sucesso!"
            : "Pagamento cadastrado com sucesso!");

        formPagamento.reset();
        pagamentoEmEdicao = null;

        await carregarPagamentos();

    } catch (erro) {
        console.error("Erro:", erro);
        alert("Não foi possível salvar o pagamento. Verifique o console.");
    }
});


window.editarPagamento = async function(id) {
    try {
        const resposta = await fetch(`${API_URL}/Pagamentos/${id}`);

        if (!resposta.ok) {
            throw new Error("Erro ao buscar pagamento.");
        }

        const pagamento = await resposta.json();

        await carregarTutoresNoSelectPagamento();

        document.getElementById("tutorPagamento").value = pagamento.tutorId;
        document.getElementById("valorPagamento").value = pagamento.valor;

        const data = new Date(pagamento.dataPagamento);
        data.setMinutes(data.getMinutes() - data.getTimezoneOffset());

        document.getElementById("dataPagamento").value =
            data.toISOString().slice(0, 16);

        document.getElementById("formaPagamento").value =
            pagamento.formaPagamento;

        document.getElementById("statusPagamento").value =
            pagamento.status;

        document.getElementById("descricaoPagamento").value =
            pagamento.descricao;

        pagamentoEmEdicao = id;

        mostrarSecao("pagamentos");

        document.querySelector("#formPagamento button[type='submit']")
            .textContent = "Salvar Alterações";

    } catch (erro) {
        console.error("Erro ao editar pagamento:", erro);
        alert("Não foi possível carregar o pagamento.");
    }
};


window.excluirPagamento = async function(id) {
    const confirmar = confirm("Deseja realmente excluir este pagamento?");

    if (!confirmar) {
        return;
    }

    try {
        const resposta = await fetch(`${API_URL}/Pagamentos/${id}`, {
            method: "DELETE"
        });

        if (!resposta.ok) {
            throw new Error("Erro ao excluir pagamento.");
        }

        alert("Pagamento excluído com sucesso!");

        await carregarPagamentos();

    } catch (erro) {
        console.error("Erro ao excluir pagamento:", erro);
        alert("Não foi possível excluir o pagamento.");
    }
};


window.gerarRelatorio = async function() {
    const tipo = document.getElementById("tipoRelatorio").value;
    const dataInicial = document.getElementById("dataInicialRelatorio").value;
    const dataFinal = document.getElementById("dataFinalRelatorio").value;

    const cabecalho = document.getElementById("cabecalhoRelatorio");
    const lista = document.getElementById("listaRelatorio");
    const resumo = document.getElementById("resumoRelatorio");
    const mensagem = document.getElementById("mensagemRelatorio");

    cabecalho.innerHTML = "";
    lista.innerHTML = "";
    resumo.textContent = "";
    mensagem.textContent = "";

    if (dataInicial && dataFinal && dataInicial > dataFinal) {
        mensagem.textContent = "A data inicial não pode ser maior que a data final.";
        return;
    }

    const configuracoes = {
        tutores: {
            endpoint: "Tutores",
            colunas: [
                { titulo: "Nome", campo: "nome" },
                { titulo: "E-mail", campo: "email" },
                { titulo: "Telefone", campo: "telefone" },
                { titulo: "Endereço", campo: "endereco" }
            ]
        },
        animais: {
            endpoint: "Animais",
            colunas: [
                { titulo: "Nome", campo: "nome" },
                { titulo: "Espécie", campo: "especie" },
                { titulo: "Raça", campo: "raca" },
                { titulo: "Sexo", campo: "sexo" },
                { titulo: "Tutor", campo: "tutor", formatar: animal => animal.tutor?.nome || "Não informado" }
            ]
        },
        consultas: {
            endpoint: "Consultas",
            colunas: [
                { titulo: "Animal", campo: "animal", formatar: consulta => consulta.animal?.nome || "Não informado" },
                { titulo: "Data", campo: "dataConsulta", formatar: consulta => new Date(consulta.dataConsulta).toLocaleString("pt-BR") },
                { titulo: "Motivo", campo: "motivo" },
                { titulo: "Diagnóstico", campo: "diagnostico" },
                { titulo: "Tratamento", campo: "tratamento" }
            ],
            campoData: "dataConsulta"
        },
        pagamentos: {
            endpoint: "Pagamentos",
            colunas: [
                { titulo: "Tutor", campo: "tutor", formatar: pagamento => pagamento.tutor?.nome || "Não informado" },
                { titulo: "Valor", campo: "valor", formatar: pagamento => Number(pagamento.valor).toLocaleString("pt-BR", { style: "currency", currency: "BRL" }) },
                { titulo: "Data", campo: "dataPagamento", formatar: pagamento => new Date(pagamento.dataPagamento).toLocaleString("pt-BR") },
                { titulo: "Forma de pagamento", campo: "formaPagamento" },
                { titulo: "Status", campo: "status" },
                { titulo: "Descrição", campo: "descricao" }
            ],
            campoData: "dataPagamento"
        }
    };

    const configuracao = configuracoes[tipo];

    try {
        const resposta = await fetch(`${API_URL}/${configuracao.endpoint}`);

        if (!resposta.ok) {
            throw new Error("Não foi possível buscar os dados.");
        }

        let dados = await resposta.json();

        // Os filtros de período são aplicados a consultas e pagamentos.
        if (configuracao.campoData) {
            dados = dados.filter(item => {
                const data = new Date(item[configuracao.campoData])
                    .toISOString().slice(0, 10);

                if (dataInicial && data < dataInicial) return false;
                if (dataFinal && data > dataFinal) return false;

                return true;
            });
        }

        const linhaCabecalho = document.createElement("tr");

        configuracao.colunas.forEach(coluna => {
            const th = document.createElement("th");
            th.textContent = coluna.titulo;
            linhaCabecalho.appendChild(th);
        });

        cabecalho.appendChild(linhaCabecalho);

        dados.forEach(item => {
            const linha = document.createElement("tr");

            configuracao.colunas.forEach(coluna => {
                const td = document.createElement("td");

                const valor = coluna.formatar
                    ? coluna.formatar(item)
                    : item[coluna.campo];

                td.textContent = valor ?? "";

                linha.appendChild(td);
            });

            lista.appendChild(linha);
        });

        resumo.textContent = `Total de registros encontrados: ${dados.length}`;

        if (dados.length === 0) {
            mensagem.textContent = "Nenhum registro encontrado para este relatório.";
        }

    } catch (erro) {
        console.error("Erro ao gerar relatório:", erro);
        mensagem.textContent = "Não foi possível gerar o relatório. Verifique se a API está funcionando.";
    }
};

window.imprimirRelatorio = function() {
    window.print();
};


window.carregarDashboard = async function() {
    try {
        const [tutores, animais, veterinarios, consultas, pagamentos] =
            await Promise.all([
                fetch(`${API_URL}/Tutores`).then(r => {
                    if (!r.ok) throw new Error("Erro ao buscar tutores");
                    return r.json();
                }),
                fetch(`${API_URL}/Animais`).then(r => {
                    if (!r.ok) throw new Error("Erro ao buscar animais");
                    return r.json();
                }),
                fetch(`${API_URL}/Veterinarios`).then(r => {
                    if (!r.ok) throw new Error("Erro ao buscar veterinários");
                    return r.json();
                }),
                fetch(`${API_URL}/Consultas`).then(r => {
                    if (!r.ok) throw new Error("Erro ao buscar consultas");
                    return r.json();
                }),
                fetch(`${API_URL}/Pagamentos`).then(r => {
                    if (!r.ok) throw new Error("Erro ao buscar pagamentos");
                    return r.json();
                })
            ]);

        document.getElementById("totalTutores").textContent = tutores.length;
        document.getElementById("totalAnimais").textContent = animais.length;
        document.getElementById("totalVeterinarios").textContent = veterinarios.length;
        document.getElementById("totalConsultas").textContent = consultas.length;
        document.getElementById("totalPagamentos").textContent = pagamentos.length;

        document.getElementById("resumoDashboard").textContent =
            `O PetCare possui ${tutores.length} tutores, ${animais.length} animais, ` +
            `${veterinarios.length} veterinários, ${consultas.length} consultas e ` +
            `${pagamentos.length} pagamentos cadastrados.`;
            
const ultimas = [...consultas]
.sort((a, b) => new Date(b.dataConsulta) - new Date(a.dataConsulta))
.slice(0, 5);

const tabelaConsultas = document.getElementById("ultimasConsultas");

tabelaConsultas.innerHTML = "";

ultimas.forEach(consulta => {
const linha = document.createElement("tr");

linha.innerHTML = `
    <td>${consulta.animal?.nome || "Não informado"}</td>
    <td>${new Date(consulta.dataConsulta).toLocaleString("pt-BR")}</td>
    <td>${consulta.motivo || ""}</td>
    <td>${consulta.diagnostico || ""}</td>
`;

tabelaConsultas.appendChild(linha);
});

if (ultimas.length === 0) {
tabelaConsultas.innerHTML = `
    <tr>
        <td colspan="4">Nenhuma consulta cadastrada.</td>
    </tr>
`;
}


    } catch (erro) {
        console.error("Erro ao carregar Dashboard:", erro);

        document.getElementById("resumoDashboard").textContent =
            "Não foi possível carregar os indicadores. Verifique se a API está funcionando.";
    }
};

carregarDashboard();

 

 
















