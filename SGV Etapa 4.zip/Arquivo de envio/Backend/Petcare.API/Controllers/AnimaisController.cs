﻿using Microsoft.AspNetCore.Mvc;
using Petcare.API.Models;
using Petcare.API.Repositories;

namespace Petcare.API.Controllers
{
   
        [ApiController]
        [Route("api/[controller]")]
        public class AnimaisController : ControllerBase
        {
            private readonly IAnimalRepository _repository;

            public AnimaisController(IAnimalRepository repository)
            {
                _repository = repository;
            }

            [HttpGet]
            public async Task<ActionResult<List<Animal>>> Listar()
            {
                return Ok(await _repository.ListarTodos());
            }

            [HttpGet("{id}")]
            public async Task<ActionResult<Animal>> BuscarPorId(int id)
            {
                var animal = await _repository.BuscarPorId(id);

                if (animal == null)
                    return NotFound();

                return Ok(animal);
            }

            [HttpPost]
            public async Task<ActionResult<Animal>> Criar(Animal animal)
            {
                await _repository.Adicionar(animal);

                return CreatedAtAction(
                    nameof(BuscarPorId),
                    new { id = animal.Id },
                    animal);
            }

            [HttpPut("{id}")]
            public async Task<IActionResult> Atualizar(int id, Animal animal)
            {
                if (id != animal.Id)
                    return BadRequest("O ID da rota é diferente do ID do animal.");

                var existente = await _repository.BuscarPorId(id);

                if (existente == null)
                    return NotFound();

                await _repository.Atualizar(animal);

                return NoContent();
            }

            [HttpDelete("{id}")]
            public async Task<IActionResult> Excluir(int id)
            {
                var animal = await _repository.BuscarPorId(id);

                if (animal == null)
                    return NotFound();

                await _repository.Excluir(id);

                return NoContent();
            }
        }
    }

