﻿using Microsoft.AspNetCore.Mvc;
using Petcare.API.Data;
using Petcare.API.Models;
using Microsoft.EntityFrameworkCore;

namespace Petcare.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class VeterinariosController : ControllerBase
    {
        private readonly VeterinariaDbContext _context;

        public VeterinariosController(VeterinariaDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Veterinario>>> Listar()
        {
            return Ok(await _context.Veterinarios.ToListAsync());
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<Veterinario>> BuscarPorId(int id)
        {
            var veterinario = await _context.Veterinarios.FindAsync(id);

            if (veterinario == null)
                return NotFound();

            return Ok(veterinario);
        }

        [HttpPost]
        public async Task<ActionResult<Veterinario>> Cadastrar(Veterinario veterinario)
        {
            _context.Veterinarios.Add(veterinario);
            await _context.SaveChangesAsync();

            return CreatedAtAction(
                nameof(BuscarPorId),
                new { id = veterinario.Id },
                veterinario
            );
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Atualizar(int id, Veterinario veterinario)
        {
            if (id != veterinario.Id)
                return BadRequest();

            var existente = await _context.Veterinarios.FindAsync(id);

            if (existente == null)
                return NotFound();

            existente.Nome = veterinario.Nome;
            existente.Crmv = veterinario.Crmv;
            existente.Email = veterinario.Email;
            existente.Telefone = veterinario.Telefone;
            existente.Especialidade = veterinario.Especialidade;

            await _context.SaveChangesAsync();

            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Excluir(int id)
        {
            var veterinario = await _context.Veterinarios.FindAsync(id);

            if (veterinario == null)
                return NotFound();

            _context.Veterinarios.Remove(veterinario);
            await _context.SaveChangesAsync();

            return NoContent();
        }
    }
}
