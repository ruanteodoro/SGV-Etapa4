﻿using Microsoft.AspNetCore.Mvc;
using Petcare.API.Data;
using Petcare.API.Models;
using Microsoft.EntityFrameworkCore;

namespace Petcare.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ProntuariosController : ControllerBase
    {
        private readonly VeterinariaDbContext _context;

        public ProntuariosController(VeterinariaDbContext context)
        {
            _context = context;
        }

        // LISTAR TODOS OS PRONTUÁRIOS
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Prontuario>>> Listar()
        {
            var prontuarios = await _context.Prontuarios
                .Include(p => p.Animal)
                .ToListAsync();

            return Ok(prontuarios);
        }

        // BUSCAR PRONTUÁRIO POR ID
        [HttpGet("{id}")]
        public async Task<ActionResult<Prontuario>> BuscarPorId(int id)
        {
            var prontuario = await _context.Prontuarios
                .Include(p => p.Animal)
                .FirstOrDefaultAsync(p => p.Id == id);

            if (prontuario == null)
                return NotFound();

            return Ok(prontuario);
        }

        // CADASTRAR PRONTUÁRIO
        [HttpPost]
        public async Task<ActionResult<Prontuario>> Cadastrar(Prontuario prontuario)
        {
            _context.Prontuarios.Add(prontuario);
            await _context.SaveChangesAsync();

            return CreatedAtAction(
                nameof(BuscarPorId),
                new { id = prontuario.Id },
                prontuario
            );
        }

        // ATUALIZAR PRONTUÁRIO
        [HttpPut("{id}")]
        public async Task<IActionResult> Atualizar(int id, Prontuario prontuario)
        {
            if (id != prontuario.Id)
                return BadRequest();

            var existente = await _context.Prontuarios.FindAsync(id);

            if (existente == null)
                return NotFound();

            existente.AnimalId = prontuario.AnimalId;
            existente.DataRegistro = prontuario.DataRegistro;
            existente.Descricao = prontuario.Descricao;
            existente.Diagnostico = prontuario.Diagnostico;
            existente.Tratamento = prontuario.Tratamento;
            existente.Observacoes = prontuario.Observacoes;

            await _context.SaveChangesAsync();

            return NoContent();
        }

        // EXCLUIR PRONTUÁRIO
        [HttpDelete("{id}")]
        public async Task<IActionResult> Excluir(int id)
        {
            var prontuario = await _context.Prontuarios.FindAsync(id);

            if (prontuario == null)
                return NotFound();

            _context.Prontuarios.Remove(prontuario);
            await _context.SaveChangesAsync();

            return NoContent();
        }
    }
}
