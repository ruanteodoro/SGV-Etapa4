﻿using Microsoft.AspNetCore.Mvc;
using Petcare.API.Models;
using Petcare.API.Repositories;

namespace Petcare.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ConsultasController : ControllerBase
    {
        private readonly IConsultaRepository _repository;

        public ConsultasController(IConsultaRepository repository)
        {
            _repository = repository;
        }

        [HttpGet]
        public async Task<ActionResult<List<Consulta>>> Listar()
        {
            return Ok(await _repository.ListarTodas());
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<Consulta>> BuscarPorId(int id)
        {
            var consulta = await _repository.BuscarPorId(id);

            if (consulta == null)
                return NotFound();

            return Ok(consulta);
        }

        [HttpPost]
        public async Task<ActionResult<Consulta>> Criar(Consulta consulta)
        {
            await _repository.Adicionar(consulta);

            return CreatedAtAction(
                nameof(BuscarPorId),
                new { id = consulta.Id },
                consulta);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Atualizar(int id, Consulta consulta)
        {
            if (id != consulta.Id)
                return BadRequest("O ID da rota é diferente do ID da consulta.");

            var existente = await _repository.BuscarPorId(id);

            if (existente == null)
                return NotFound();

            await _repository.Atualizar(consulta);

            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Excluir(int id)
        {
            var consulta = await _repository.BuscarPorId(id);

            if (consulta == null)
                return NotFound();

            await _repository.Excluir(id);

            return NoContent();
        }
    }
}
