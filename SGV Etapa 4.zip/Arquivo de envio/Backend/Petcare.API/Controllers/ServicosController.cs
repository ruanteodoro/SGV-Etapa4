﻿using Microsoft.AspNetCore.Mvc;
using Petcare.API.Data;
using Petcare.API.Models;
using Microsoft.EntityFrameworkCore;

namespace Petcare.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ServicosController : ControllerBase
    {
        private readonly VeterinariaDbContext _context;

        public ServicosController(VeterinariaDbContext context)
        {
            _context = context;
        }

        // Listar todos os serviços
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Servico>>> Listar()
        {
            var servicos = await _context.Servicos.ToListAsync();

            return Ok(servicos);
        }

        // Buscar serviço por ID
        [HttpGet("{id}")]
        public async Task<ActionResult<Servico>> BuscarPorId(int id)
        {
            var servico = await _context.Servicos.FindAsync(id);

            if (servico == null)
                return NotFound();

            return Ok(servico);
        }

        // Cadastrar serviço
        [HttpPost]
        public async Task<ActionResult<Servico>> Cadastrar(Servico servico)
        {
            _context.Servicos.Add(servico);
            await _context.SaveChangesAsync();

            return CreatedAtAction(
                nameof(BuscarPorId),
                new { id = servico.Id },
                servico
            );
        }

        // Atualizar serviço
        [HttpPut("{id}")]
        public async Task<IActionResult> Atualizar(int id, Servico servico)
        {
            if (id != servico.Id)
                return BadRequest();

            var existente = await _context.Servicos.FindAsync(id);

            if (existente == null)
                return NotFound();

            existente.Nome = servico.Nome;
            existente.Descricao = servico.Descricao;
            existente.Preco = servico.Preco;
            existente.DuracaoMinutos = servico.DuracaoMinutos;

            await _context.SaveChangesAsync();

            return NoContent();
        }

        // Excluir serviço
        [HttpDelete("{id}")]
        public async Task<IActionResult> Excluir(int id)
        {
            var servico = await _context.Servicos.FindAsync(id);

            if (servico == null)
                return NotFound();

            _context.Servicos.Remove(servico);
            await _context.SaveChangesAsync();

            return NoContent();
        }
    }
}
