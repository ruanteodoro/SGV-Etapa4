﻿using Microsoft.AspNetCore.Mvc;
using Petcare.API.Data;
using Petcare.API.Models;
using Microsoft.EntityFrameworkCore;

namespace Petcare.API.Controllers
{
   
        [ApiController]
        [Route("api/[controller]")]
        public class VacinasController : ControllerBase
        {
            private readonly VeterinariaDbContext _context;

            public VacinasController(VeterinariaDbContext context)
            {
                _context = context;
            }

            // LISTAR VACINAS
            [HttpGet]
            public async Task<ActionResult<IEnumerable<Vacina>>> Listar()
            {
                var vacinas = await _context.Vacinas
                    .Include(v => v.Animal)
                    .ToListAsync();

                return Ok(vacinas);
            }

            // BUSCAR POR ID
            [HttpGet("{id}")]
            public async Task<ActionResult<Vacina>> BuscarPorId(int id)
            {
                var vacina = await _context.Vacinas
                    .Include(v => v.Animal)
                    .FirstOrDefaultAsync(v => v.Id == id);

                if (vacina == null)
                    return NotFound();

                return Ok(vacina);
            }

            // CADASTRAR
            [HttpPost]
            public async Task<ActionResult<Vacina>> Cadastrar(Vacina vacina)
            {
                _context.Vacinas.Add(vacina);
                await _context.SaveChangesAsync();

                return CreatedAtAction(
                    nameof(BuscarPorId),
                    new { id = vacina.Id },
                    vacina
                );
            }

            // ATUALIZAR
            [HttpPut("{id}")]
            public async Task<IActionResult> Atualizar(int id, Vacina vacina)
            {
                if (id != vacina.Id)
                    return BadRequest();

                var existente = await _context.Vacinas.FindAsync(id);

                if (existente == null)
                    return NotFound();

                existente.AnimalId = vacina.AnimalId;
                existente.Nome = vacina.Nome;
                existente.DataAplicacao = vacina.DataAplicacao;
                existente.DataProximaDose = vacina.DataProximaDose;
                existente.VeterinarioResponsavel = vacina.VeterinarioResponsavel;
                existente.Observacoes = vacina.Observacoes;

                await _context.SaveChangesAsync();

                return NoContent();
            }

            // EXCLUIR
            [HttpDelete("{id}")]
            public async Task<IActionResult> Excluir(int id)
            {
                var vacina = await _context.Vacinas.FindAsync(id);

                if (vacina == null)
                    return NotFound();

                _context.Vacinas.Remove(vacina);
                await _context.SaveChangesAsync();

                return NoContent();
            }
        }
    
}
