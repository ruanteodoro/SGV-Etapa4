﻿using Microsoft.AspNetCore.Mvc;
using Petcare.API.Data;
using Petcare.API.Models;
using Microsoft.EntityFrameworkCore;

namespace Petcare.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class PagamentosController : ControllerBase
    {
        private readonly VeterinariaDbContext _context;

        public PagamentosController(VeterinariaDbContext context)
        {
            _context = context;
        }

        // Listar todos os pagamentos
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Pagamento>>> Listar()
        {
            var pagamentos = await _context.Pagamentos
                .Include(p => p.Tutor)
                .ToListAsync();

            return Ok(pagamentos);
        }

        // Buscar pagamento por ID
        [HttpGet("{id}")]
        public async Task<ActionResult<Pagamento>> BuscarPorId(int id)
        {
            var pagamento = await _context.Pagamentos
                .Include(p => p.Tutor)
                .FirstOrDefaultAsync(p => p.Id == id);

            if (pagamento == null)
                return NotFound();

            return Ok(pagamento);
        }

        // Cadastrar pagamento
        [HttpPost]
        public async Task<ActionResult<Pagamento>> Cadastrar(Pagamento pagamento)
        {
            _context.Pagamentos.Add(pagamento);
            await _context.SaveChangesAsync();

            return CreatedAtAction(
                nameof(BuscarPorId),
                new { id = pagamento.Id },
                pagamento
            );
        }

        // Atualizar pagamento
        [HttpPut("{id}")]
        public async Task<IActionResult> Atualizar(int id, Pagamento pagamento)
        {
            if (id != pagamento.Id)
                return BadRequest();

            var existente = await _context.Pagamentos.FindAsync(id);

            if (existente == null)
                return NotFound();

            existente.TutorId = pagamento.TutorId;
            existente.Valor = pagamento.Valor;
            existente.DataPagamento = pagamento.DataPagamento;
            existente.FormaPagamento = pagamento.FormaPagamento;
            existente.Status = pagamento.Status;
            existente.Descricao = pagamento.Descricao;

            await _context.SaveChangesAsync();

            return NoContent();
        }

        // Excluir pagamento
        [HttpDelete("{id}")]
        public async Task<IActionResult> Excluir(int id)
        {
            var pagamento = await _context.Pagamentos.FindAsync(id);

            if (pagamento == null)
                return NotFound();

            _context.Pagamentos.Remove(pagamento);
            await _context.SaveChangesAsync();

            return NoContent();
        }
    }
}
