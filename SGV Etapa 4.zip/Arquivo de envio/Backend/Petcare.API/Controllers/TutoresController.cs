﻿using Microsoft.AspNetCore.Mvc;
using Petcare.API.Models;
using Petcare.API.Repositories;

namespace Petcare.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class TutoresController : ControllerBase
    {
        private readonly ITutorRepository _repository;

        public TutoresController(ITutorRepository repository)
        {
            _repository = repository;
        }

        [HttpGet]
        public async Task<ActionResult<List<Tutor>>> Listar()
        {
            return Ok(await _repository.ListarTodos());
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<Tutor>> BuscarPorId(int id)
        {
            var tutor = await _repository.BuscarPorId(id);

            if (tutor == null)
                return NotFound();

            return Ok(tutor);
        }

        [HttpPost]
        public async Task<ActionResult<Tutor>> Criar(Tutor tutor)
        {
            await _repository.Adicionar(tutor);

            return CreatedAtAction(
                nameof(BuscarPorId),
                new { id = tutor.Id },
                tutor);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Atualizar(int id, Tutor tutor)
        {
            if (id != tutor.Id)
                return BadRequest("O ID da rota é diferente do ID do tutor.");

            var existente = await _repository.BuscarPorId(id);

            if (existente == null)
                return NotFound();

            await _repository.Atualizar(tutor);

            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Excluir(int id)
        {
            var tutor = await _repository.BuscarPorId(id);

            if (tutor == null)
                return NotFound();

            await _repository.Excluir(id);

            return NoContent();
        }
    }
}
