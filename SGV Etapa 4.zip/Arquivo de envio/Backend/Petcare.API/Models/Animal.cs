﻿using System.ComponentModel.DataAnnotations;

namespace Petcare.API.Models
{
    public class Animal
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "O nome do animal é obrigatório.")]
        [StringLength(100)]
        public string Nome { get; set; } = string.Empty;

        [Required(ErrorMessage = "A espécie é obrigatória.")]
        [StringLength(50)]
        public string Especie { get; set; } = string.Empty;

        [StringLength(50)]
        public string Raca { get; set; } = string.Empty;

        public DateTime DataNascimento { get; set; }

        [StringLength(20)]
        public string Sexo { get; set; } = string.Empty;

        public int TutorId { get; set; }

        public Tutor? Tutor { get; set; }
    }
}

