﻿namespace Petcare.API.Models
{
    public class Prontuario
    {
        public int Id { get; set; }

        public int AnimalId { get; set; }

        public Animal? Animal { get; set; }

        public DateTime DataRegistro { get; set; }

        public string Descricao { get; set; } = string.Empty;

        public string Diagnostico { get; set; } = string.Empty;

        public string Tratamento { get; set; } = string.Empty;

        public string Observacoes { get; set; } = string.Empty;
    }
}
