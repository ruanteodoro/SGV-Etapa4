﻿namespace Petcare.API.Models
{
    public class Veterinario
    {
        public int Id { get; set; }

        public string Nome { get; set; } = string.Empty;

        public string Crmv { get; set; } = string.Empty;

        public string Email { get; set; } = string.Empty;

        public string Telefone { get; set; } = string.Empty;

        public string Especialidade { get; set; } = string.Empty;
    }
}
