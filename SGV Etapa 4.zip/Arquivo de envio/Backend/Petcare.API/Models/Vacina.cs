﻿namespace Petcare.API.Models
{
    public class Vacina
    {
       
        
            public int Id { get; set; }

            public int AnimalId { get; set; }

            public Animal? Animal { get; set; }

            public string Nome { get; set; } = string.Empty;

            public DateTime DataAplicacao { get; set; }

            public DateTime? DataProximaDose { get; set; }

            public string VeterinarioResponsavel { get; set; } = string.Empty;

            public string Observacoes { get; set; } = string.Empty;
        
    }
}
