﻿using System.ComponentModel.DataAnnotations;

namespace Petcare.API.Models
{
    public class Consulta
    {
        public int Id { get; set; }

        [Required]
        public int AnimalId { get; set; }

        public Animal? Animal { get; set; }

        [Required(ErrorMessage = "A data da consulta é obrigatória.")]
        public DateTime DataConsulta { get; set; }

        [Required(ErrorMessage = "O motivo da consulta é obrigatório.")]
        [StringLength(300)]
        public string Motivo { get; set; } = string.Empty;

        [StringLength(1000)]
        public string Diagnostico { get; set; } = string.Empty;

        [StringLength(1000)]
        public string Tratamento { get; set; } = string.Empty;
    }
}
