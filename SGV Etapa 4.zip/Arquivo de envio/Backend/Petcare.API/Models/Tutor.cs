﻿using System.ComponentModel.DataAnnotations;

namespace Petcare.API.Models
{
    public class Tutor
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "O nome do tutor é obrigatório.")]
        [StringLength(100)]
        public string Nome { get; set; } = string.Empty;

        [Required(ErrorMessage = "O e-mail é obrigatório.")]
        [EmailAddress(ErrorMessage = "Informe um e-mail válido.")]
        [StringLength(150)]
        public string Email { get; set; } = string.Empty;

        [Required(ErrorMessage = "O telefone é obrigatório.")]
        [StringLength(20)]
        public string Telefone { get; set; } = string.Empty;

        [StringLength(200)]
        public string Endereco { get; set; } = string.Empty;
    }
}
