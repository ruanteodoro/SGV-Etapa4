﻿namespace Petcare.API.Models
{
    public class Pagamento
    {
        public int Id { get; set; }

        public int TutorId { get; set; }
        public Tutor? Tutor { get; set; }

        public decimal Valor { get; set; }

        public DateTime DataPagamento { get; set; }

        public string FormaPagamento { get; set; } = string.Empty;

        public string Status { get; set; } = string.Empty;

        public string Descricao { get; set; } = string.Empty;
    }
}
