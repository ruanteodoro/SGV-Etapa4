﻿

using Microsoft.EntityFrameworkCore;
using Petcare.API.Models;

namespace Petcare.API.Data
{
    public class VeterinariaDbContext : DbContext
    {
        public VeterinariaDbContext(
            DbContextOptions<VeterinariaDbContext> options)
            : base(options)
        {
        }

        public DbSet<Animal> Animais { get; set; }

        public DbSet<Tutor> Tutores { get; set; }

        public DbSet<Consulta> Consultas { get; set; }

        public DbSet<Veterinario> Veterinarios { get; set; }

        public DbSet<Prontuario> Prontuarios { get; set;}

        public DbSet<Vacina> Vacinas { get; set;}

        public DbSet<Servico> Servicos { get; set; }

        public DbSet<Pagamento> Pagamentos { get; set; }



        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Pagamento>()
                .Property(p => p.Valor)
                .HasPrecision(18, 2);

            modelBuilder.Entity<Servico>()
                .Property(s => s.Preco)
                .HasPrecision(18, 2);
        }

    }

}

