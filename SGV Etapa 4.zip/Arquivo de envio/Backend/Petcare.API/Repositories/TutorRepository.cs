﻿using Petcare.API.Data;
using Petcare.API.Models;
using Microsoft.EntityFrameworkCore;

namespace Petcare.API.Repositories
{
    public class TutorRepository : ITutorRepository
    {
        private readonly VeterinariaDbContext _context;

        public TutorRepository(VeterinariaDbContext context)
        {
            _context = context;
        }

        public async Task<List<Tutor>> ListarTodos()
        {
            return await _context.Tutores
                .AsNoTracking()
                .ToListAsync();
        }

        public async Task<Tutor?> BuscarPorId(int id)
        {
            return await _context.Tutores
                .AsNoTracking()
                .FirstOrDefaultAsync(t => t.Id == id);
        }

        public async Task Adicionar(Tutor tutor)
        {
            _context.Tutores.Add(tutor);
            await _context.SaveChangesAsync();
        }

        public async Task Atualizar(Tutor tutor)
        {
            _context.Tutores.Update(tutor);
            await _context.SaveChangesAsync();
        }

        public async Task Excluir(int id)
        {
            var tutor = await _context.Tutores.FindAsync(id);

            if (tutor != null)
            {
                _context.Tutores.Remove(tutor);
                await _context.SaveChangesAsync();
            }
        }
    }
}
