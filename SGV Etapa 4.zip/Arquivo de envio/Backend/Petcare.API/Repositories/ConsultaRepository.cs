﻿using Petcare.API.Data;
using Petcare.API.Models;
using Microsoft.EntityFrameworkCore;

namespace Petcare.API.Repositories
{
    public class ConsultaRepository : IConsultaRepository
    {
        private readonly VeterinariaDbContext _context;

        public ConsultaRepository(VeterinariaDbContext context)
        {
            _context = context;
        }

        public async Task<List<Consulta>> ListarTodas()
        {
            return await _context.Consultas
                .Include(c => c.Animal)
                .AsNoTracking()
                .ToListAsync();
        }

        public async Task<Consulta?> BuscarPorId(int id)
        {
            return await _context.Consultas
                .Include(c => c.Animal)
                .AsNoTracking()
                .FirstOrDefaultAsync(c => c.Id == id);
        }

        public async Task Adicionar(Consulta consulta)
        {
            _context.Consultas.Add(consulta);
            await _context.SaveChangesAsync();
        }

        public async Task Atualizar(Consulta consulta)
        {
            _context.Consultas.Update(consulta);
            await _context.SaveChangesAsync();
        }

        public async Task Excluir(int id)
        {
            var consulta = await _context.Consultas.FindAsync(id);

            if (consulta != null)
            {
                _context.Consultas.Remove(consulta);
                await _context.SaveChangesAsync();
            }
        }
    }
}

