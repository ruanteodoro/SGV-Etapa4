﻿using Petcare.API.Models;

namespace Petcare.API.Repositories
{
    public interface IAnimalRepository
    {
        Task<List<Animal>> ListarTodos();
        Task<Animal?> BuscarPorId(int id);
        Task Adicionar(Animal animal);
        Task Atualizar(Animal animal);
        Task Excluir(int id);
    }
}
