﻿using Petcare.API.Models;

namespace Petcare.API.Repositories
{
    public interface ITutorRepository
    {
        Task<List<Tutor>> ListarTodos();
        Task<Tutor?> BuscarPorId(int id);
        Task Adicionar(Tutor tutor);
        Task Atualizar(Tutor tutor);
        Task Excluir(int id);
    }

}
