﻿using Petcare.API.Data;
using Petcare.API.Models;
using Microsoft.EntityFrameworkCore;

namespace Petcare.API.Repositories
{
    public class AnimalRepository : IAnimalRepository
    {
        private readonly VeterinariaDbContext _context;

        public AnimalRepository(VeterinariaDbContext context)
        {
            _context = context;
        }

        public async Task<List<Animal>> ListarTodos()
        {
            return await _context.Animais
                .Include(a => a.Tutor)
                .AsNoTracking()
                .ToListAsync();
        }

        public async Task<Animal?> BuscarPorId(int id)
        {
            return await _context.Animais
                .Include(a => a.Tutor)
                .AsNoTracking()
                .FirstOrDefaultAsync(a => a.Id == id);
        }

        public async Task Adicionar(Animal animal)
        {
            _context.Animais.Add(animal);
            await _context.SaveChangesAsync();
        }

        public async Task Atualizar(Animal animal)
        {
            _context.Animais.Update(animal);
            await _context.SaveChangesAsync();
        }

        public async Task Excluir(int id)
        {
            var animal = await _context.Animais.FindAsync(id);

            if (animal != null)
            {
                _context.Animais.Remove(animal);
                await _context.SaveChangesAsync();
            }
        }
    }
}
