﻿using Petcare.API.Data;
using Petcare.API.Models;
using Microsoft.EntityFrameworkCore;

namespace Petcare.API.Repositories
{
    public interface IConsultaRepository
    {
        Task<List<Consulta>> ListarTodas();
        Task<Consulta?> BuscarPorId(int id);
        Task Adicionar(Consulta consulta);
        Task Atualizar(Consulta consulta);
        Task Excluir(int id);
    }
}
