﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Petcare.API.Migrations
{
    /// <inheritdoc />
    public partial class AjustarPrecisaoPagamento : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
